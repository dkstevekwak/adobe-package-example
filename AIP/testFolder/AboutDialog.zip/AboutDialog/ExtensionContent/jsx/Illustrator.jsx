$._ext_ILST={
    run : function() {
    
    	/**********  Replace below sample code with your own JSX code  **********/
        var appName;	    
	    appName = "Hello Illustrator";	    
        alert(appName);
        /************************************************************************/
        
        return appName;
    },
};