function AboutModelView() {
    var self = this;

    self.version = ko.observable();
    self.productType = ko.observable();
    self.remainDays = ko.observable();
    self.code = ko.observable();
    self.registryVisible = ko.observable(true);
    self.freeEditionVersionStringForDesigners = ko.observable(true);
    
    self.theVersionType = ko.observable();
    self.expirationOrCode = ko.observable();
    
    self.ok = function(){
    	var csInterface = new CSInterface();
 		
 		csInterface.closeExtension();
    };
    
    self.register = function(){
    	var csInterface = new CSInterface();
 		
 		csInterface.requestOpenExtension("indigo.wise.about.register");
    };
        
    self.requestSettings = function(){
    	var csInterface = new CSInterface();
		
		var event = new CSEvent();
		
		event.scope = "APPLICATION";
		event.type = "indigo.wise.about.requestaboutsettings";
		
		csInterface.dispatchEvent(event);
    };
    
    self.setSettings = function(event){
    	var settings = eval("(" + event.data + ")");
    	console.log(settings);
    	self.version(settings.productVersion);
    	self.productType(settings.licenseType);
    	self.remainDays(settings.remainDays);
    	self.code(settings.code);
    	self.registryVisible(settings.editable);
    	self.freeEditionVersionStringForDesigners(settings.editable);
    	
    	var str1 = self.getTheVersionType();     	
       	document.getElementById("string1").value = str1;
    	self.theVersionType(str1);
   	
    	var str2 = self.getExpirationOrCode();
      	document.getElementById("string2").value = str2;    	
       	self.expirationOrCode(str2);
    };
    
    self.getString = function(str){
    	if (!resourceBundle){
    		var csInterface = new CSInterface();
    		resourceBundle = csInterface.initResourceBundle();
    	}
    	return resourceBundle[str];
    };
	    
    self.getTheVersionType = function(){
    	var str = "";
    	
    	if(!self.freeEditionVersionStringForDesigners()){
    		str = self.getString("freeEditionVersionStringForDesigners");
    	} else {
        	if (self.productType() == "TrialLicense")
        		str = self.getString("trialVersionString");
        	else if (self.productType() == "FullLicense")
        		str = self.getString("fullVersionString");
        	else
        		str = self.getString("limitedVersionString");
    	}
    		
    	return str;
    };
    
    self.getExpirationOrCode = function(){
    	var str = "";
    	if (self.productType() == "TrialLicense"){
    		str = self.getString("expirationString").replace("^0", this.remainDays());
    	} else if (self.productType() == "FullLicense"){
    		str = self.getString("code") + " " + this.code();
    	}
    	
    	return str;
    };
    
    self.init = function(){
    	var csInterface = new CSInterface();

    	csInterface.addEventListener("indigo.wise.about.response.aboutsettings", setSettings);	
    	
    	self.requestSettings();
    	
    	$(document).keyup(function(e) {
    		if (e.keyCode == 27) {
    			self.ok();
    		}
    	});
    };

    self.init();
};


$(document).on('dragover', function (e) {
    e.preventDefault();
    e.stopPropagation();
});

$(document).on('drop', function (e) {
    e.preventDefault();
    e.stopPropagation(); 
});

$(document).ready(function () {
    ko.applyBindings(AboutModelView());
});