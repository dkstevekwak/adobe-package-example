function ErrorModelView() {
    this.ok = function(){
    	var csInterface = new CSInterface();
 		csInterface.closeExtension();
    };
    
    $(document).keyup(function(e) {
		if (e.keyCode == 27) {
			self.ok();
		}
	});
};

$(document).on('dragover', function (e) {
    e.preventDefault();
    e.stopPropagation();
});

$(document).on('drop', function (e) {
    e.preventDefault();
    e.stopPropagation(); 
});

$(document).ready(function () {
    ko.applyBindings(ErrorModelView());
});