function RegisterModelView() {
    var self = this;
    self.part1 = ko.observable();
    self.part2 = ko.observable();
    self.part3 = ko.observable();
    self.part4 = ko.observable();
    self.part5 = ko.observable();
    self.part6 = ko.observable();
    
    self.error = ko.observable();
    
    self.ok = function(){
    	var csInterface = new CSInterface();
 		
 		var event = new CSEvent();
 		
 		event.scope = "APPLICATION";
 		event.type = "indigo.wise.about.register.ok";
		var obj = {};
 		obj["part1"] = document.getElementById("part1").value;
		obj["part2"] = document.getElementById("part2").value;
		obj["part3"] = document.getElementById("part3").value;
		obj["part4"] = document.getElementById("part4").value;
		obj["part5"] = document.getElementById("part5").value;
		obj["part6"] = document.getElementById("part6").value;
		event.data = ko.toJSON(obj);

 		csInterface.dispatchEvent(event);
 	};
    
    self.cancel = function(){
    	var csInterface = new CSInterface();
 		
 		csInterface.closeExtension();
    };
    
    self.getString = function(str){
    	if (!resourceBundle){
    		var csInterface = new CSInterface();
    		resourceBundle = csInterface.initResourceBundle();
    	}
    	return resourceBundle[str];
    };
    
    self.onValid = function(){
    	var csInterface = new CSInterface();
		
		var event = new CSEvent();
		
		event.scope = "APPLICATION";
		event.type = "indigo.wise.about.requestaboutsettings";
		
		csInterface.dispatchEvent(event);
		
    	csInterface.closeExtension();
    };

    self.requestSettings = function(){
    	var csInterface = new CSInterface();
		
		var event = new CSEvent();
		
		event.scope = "APPLICATION";
		event.type = "indigo.wise.about.requestregsettings";
		
		csInterface.dispatchEvent(event);
    };

    self.setSettings = function(event){
    	var settings = eval("(" + event.data + ")");
    	
       	self.part1(settings.part1);
       	self.part2(settings.part2);
       	self.part3(settings.part3);
       	self.part4(settings.part4);
       	self.part5(settings.part5);
       	self.part6(settings.part6);
    };

    
    self.init = function(){
    	var csInterface = new CSInterface();

    	csInterface.addEventListener("indigo.wise.about.response.regsettings", setSettings);		
    	csInterface.addEventListener("indigo.wise.about.register.response.valid", onValid);		
	
    	self.requestSettings();
    	
    	$(document).keyup(function(e) {
    		if (e.keyCode == 27) {
    			self.cancel();
    		}
    	});
	};
    
    self.init();
};

$(document).on('dragover', function (e) {
    e.preventDefault();
    e.stopPropagation();
});

$(document).on('drop', function (e) {
    e.preventDefault();
    e.stopPropagation(); 
});

$(document).ready(function () {
    ko.applyBindings(RegisterModelView());
    $('#part1').autotab({ format: 'alphanumeric', target: '#part2'});
    $('#part2').autotab({ format: 'alphanumeric', target: '#part3', previous: '#part1' });
    $('#part3').autotab({ format: 'alphanumeric', target: '#part4', previous: '#part2' });
    $('#part4').autotab({ format: 'alphanumeric', target: '#part5', previous: '#part3' });
    $('#part5').autotab({ format: 'alphanumeric', target: '#part6', previous: '#part4' });
    $('#part6').autotab({ format: 'alphanumeric', previous: '#part5' });
});